function  a=clmp(a,mina,maxa)
% Function clmp to boundaries
% a=clmp(a,mina,maxa)
a=min(max(a,mina),maxa);

